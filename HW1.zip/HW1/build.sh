#! /bin/sh

cmake -S source/ -B build/; cd build; make