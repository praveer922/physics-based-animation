#! /bin/sh

cd build/; ./hw1 sphere.obj