#! /bin/sh

cd build/; ./hw2 armadillo.obj